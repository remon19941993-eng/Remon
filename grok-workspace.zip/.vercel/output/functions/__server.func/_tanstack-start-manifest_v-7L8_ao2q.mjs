//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-7L8_ao2q.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/join",
			"/merchants",
			"/plans"
		],
		preloads: [
			"/assets/index-CVMvjBul.js",
			"/assets/createLucideIcon-CxH52fSw.js",
			"/assets/preload-helper-B2-jmbKI.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CVMvjBul.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BXXiTr74.js",
			"/assets/layout-BQJqZ_Qd.js",
			"/assets/copy-row-D99TobMt.js",
			"/assets/contact-pay-Cs8ExMtJ.js",
			"/assets/merchant-card-BGPbKbJ5.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: ["/assets/admin-ChBu1_4v.js", "/assets/layout-BQJqZ_Qd.js"]
	},
	"/join": {
		filePath: "/workspace/src/routes/join.tsx",
		children: void 0,
		preloads: [
			"/assets/join-CGv2mivN.js",
			"/assets/layout-BQJqZ_Qd.js",
			"/assets/contact-pay-Cs8ExMtJ.js"
		]
	},
	"/merchants": {
		filePath: "/workspace/src/routes/merchants.tsx",
		children: ["/merchants/$id"],
		preloads: [
			"/assets/merchants-DM_4Gnv1.js",
			"/assets/layout-BQJqZ_Qd.js",
			"/assets/merchant-card-BGPbKbJ5.js"
		]
	},
	"/plans": {
		filePath: "/workspace/src/routes/plans.tsx",
		children: void 0,
		preloads: [
			"/assets/plans-DQzRtEl_.js",
			"/assets/layout-BQJqZ_Qd.js",
			"/assets/copy-row-D99TobMt.js",
			"/assets/contact-pay-Cs8ExMtJ.js"
		]
	},
	"/merchants/$id": {
		filePath: "/workspace/src/routes/merchants.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/merchants._id-DsnHzMdO.js",
			"/assets/copy-row-D99TobMt.js",
			"/assets/map-pin-4v_oRzra.js",
			"/assets/message-circle-CIHpFLYw.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
