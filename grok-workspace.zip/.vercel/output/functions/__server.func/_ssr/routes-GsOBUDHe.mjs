import { b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Tags, n as Wallet, o as Store, x as ArrowLeft, y as BadgeCheck } from "../_libs/lucide-react.mjs";
import { d as useRemonStore, l as formatSyp, o as Shell, r as CATEGORIES } from "./layout-B_Hq2xpR.mjs";
import { t as ContactPay } from "./contact-pay-CKtAoyPv.mjs";
import { t as MerchantCard } from "./merchant-card-zEy10une.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-GsOBUDHe.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const merchants = useRemonStore((s) => s.merchants);
	const settings = useRemonStore((s) => s.settings);
	const featured = merchants.filter((m) => m.plan === "weekly").slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden bg-ink text-cream",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/hero-souk.jpg",
					alt: "",
					className: "absolute inset-0 size-full object-cover opacity-40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-l from-ink via-ink/80 to-ink/40" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative mx-auto max-w-6xl px-4 py-16 md:py-24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-6 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-1 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-gold" }), "منصة التجار — نموذج علي بابا المحلي"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "text-3xl font-bold leading-tight text-white md:text-5xl",
								children: [
									"اعرض بضاعتك للتجار",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gold",
										children: "واستقبل طلبات الجملة"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-base leading-relaxed text-cream/80 md:text-lg",
								children: "ريمون تربط التجار بالمشترين في حلب وسوريا. التاجر يشترك، يظهر، ويصل للزبون — بدون مخزون علينا وبدون تعقيد."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-wrap gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/join",
									className: "inline-flex h-12 items-center rounded-xl bg-gold px-6 font-bold text-ink transition-transform active:scale-[0.96]",
									children: "انضم كتاجر الآن"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/merchants",
									className: "inline-flex h-12 items-center rounded-xl border border-white/20 bg-white/10 px-6 text-white transition-transform active:scale-[0.96]",
									children: "تصفح التجار"
								})]
							})
						]
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "relative z-10 mx-auto -mt-8 max-w-6xl px-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: String(merchants.length),
						label: "تاجر مسجّل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: String(CATEGORIES.length),
						label: "تصنيفات"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: formatSyp(settings.weeklyPrice),
						label: "أسبوعيًا",
						gold: true
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-6 text-xl font-bold md:text-2xl",
				children: "تصنيفات الجملة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: CATEGORIES.map((c) => {
					const Icon = c.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/merchants",
						search: { cat: c.id },
						className: "group overflow-hidden rounded-[1.25rem] bg-surface shadow-card transition-[box-shadow,transform] duration-200 hover:shadow-card-hover",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative aspect-[5/3] overflow-hidden",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: c.image,
									alt: "",
									className: "size-full object-cover transition-transform duration-500 group-hover:scale-105"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-ink/25" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute top-2 right-2 flex size-8 items-center justify-center rounded-lg bg-surface/90",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-fg" })
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold",
								children: c.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-0.5 text-xs text-muted",
								children: c.blurb
							})]
						})]
					}, c.id);
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-border bg-surface py-14",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold md:text-2xl",
						children: "تجار مميزون"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/merchants",
						className: "flex items-center gap-1 text-sm text-muted",
						children: ["عرض الكل", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
					children: featured.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MerchantCard, { merchant: m }, m.id))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-8 text-center text-xl font-bold md:text-2xl",
				children: "كيف يعمل ريمون؟"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
						n: "1",
						title: "التاجر يشترك",
						body: "يسجّل متجره ويدفع الاشتراك عبر شام كاش ليظهر في المنصة."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
						n: "2",
						title: "يعرض بضاعته",
						body: "صور، أسعار جملة، ونوع النشاط — بشكل مرتب واحترافي."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
						n: "3",
						title: "الزبون يجده",
						gold: true,
						title2: "الزبون يجده",
						body: "المشترون والتجار يتواصلون مباشرة عبر واتساب ويتم الاتفاق."
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid max-w-6xl gap-6 px-4 pb-8 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[1.5rem] bg-ink p-6 text-cream sm:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-gold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-bold",
							children: "الدفع والتواصل"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 text-2xl font-bold text-white",
						children: "شام كاش + واتساب"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm leading-relaxed text-cream/70",
						children: [
							"التجربة ",
							settings.trialDays,
							" أيام مجانًا، بعدها ",
							formatSyp(settings.weeklyPrice),
							" أسبوعيًا تُحوَّل إلى حساب شام كاش أدناه. للتفعيل أرسل صورة الإشعار على رقم التواصل."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-5 space-y-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-4 text-gold" }), " ظهور المتجر في الدليل"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, { className: "size-4 text-gold" }), " زر واتساب مباشر للزبون"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tags, { className: "size-4 text-gold" }), " شارة مشترك نشط"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/plans",
						className: "mt-6 inline-flex h-11 items-center rounded-xl bg-gold px-5 font-bold text-ink",
						children: "تفاصيل الاشتراك"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactPay, { waMessage: "مرحبا، أريد الاستفسار عن الاشتراك في ريمون" })]
		})
	] });
}
function Stat({ value, label, gold }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-surface p-4 text-center shadow-card md:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `text-xl font-bold tabular-nums md:text-3xl ${gold ? "text-gold-deep" : "text-fg"}`,
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-xs text-muted md:text-sm",
			children: label
		})]
	});
}
function Step({ n, title, title2, body, gold }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[1.25rem] bg-surface p-6 text-center shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mx-auto mb-4 flex size-12 items-center justify-center rounded-full text-lg font-bold ${gold ? "bg-gold/20 text-gold-deep" : "bg-cream text-fg"}`,
				children: n
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-bold",
				children: title2 ?? title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: body
			})
		]
	});
}
//#endregion
export { Home as component };
