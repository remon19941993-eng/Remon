import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as CATEGORY_SELECT, d as useRemonStore, f as waLink, o as Shell } from "./layout-B_Hq2xpR.mjs";
import { i as Route$3 } from "./router-DN13VJYe.mjs";
import { t as ContactPay } from "./contact-pay-CKtAoyPv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/join-DC1q8Lxv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function JoinPage() {
	const { plan: planQ } = Route$3.useSearch();
	const addRequest = useRemonStore((s) => s.addRequest);
	const settings = useRemonStore((s) => s.settings);
	const [sent, setSent] = (0, import_react.useState)(false);
	function onSubmit(e) {
		e.preventDefault();
		const fd = new FormData(e.currentTarget);
		const name = String(fd.get("name") || "").trim();
		const category = String(fd.get("category") || "other");
		const phone = String(fd.get("phone") || "").trim();
		const shamCash = String(fd.get("shamCash") || "").trim();
		const city = String(fd.get("city") || "").trim();
		const desc = String(fd.get("desc") || "").trim();
		const plan = String(fd.get("plan") || "trial") || "trial";
		if (!name || !phone || !city) return;
		addRequest({
			name,
			category,
			phone,
			shamCash,
			city,
			desc,
			plan
		});
		const text = `طلب انضمام لتاجر جديد على ريمون:\nالمتجر: ${name}\nالتصنيف: ${category}\nالهاتف: ${phone}\nشام كاش: ${shamCash || "-"}\nالمدينة: ${city}\nالباقة: ${plan}\nالوصف: ${desc || "-"}`;
		const href = waLink(settings.contactPhone, text);
		if (href) window.open(href, "_blank");
		setSent(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold",
				children: "سجّل متجرك في ريمون"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "املأ البيانات وسنتواصل معك لتفعيل الحساب"
			}),
			sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-[1.25rem] bg-surface p-6 text-center shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold",
						children: "وصل طلبك"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: "افتح واتساب لإكمال الإرسال إن لم يُفتح تلقائيًا. يمكنك أيضًا تحويل الاشتراك إلى حساب شام كاش أدناه."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactPay, { waMessage: "مرحبا، أرسلت طلب انضمام إلى ريمون" })
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mt-6 space-y-4 rounded-[1.25rem] bg-surface p-6 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "اسم المتجر / التاجر",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							name: "name",
							required: true,
							placeholder: "مثال: مؤسسة النور للأقمشة",
							className: "field"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "التصنيف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							name: "category",
							required: true,
							className: "field",
							defaultValue: "",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								disabled: true,
								children: "اختر التصنيف"
							}), CATEGORY_SELECT.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c.id,
								children: c.name
							}, c.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "رقم التواصل (واتساب)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							name: "phone",
							required: true,
							dir: "ltr",
							placeholder: "09xxxxxxxx",
							className: "field"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "حساب شام كاش (اختياري)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							name: "shamCash",
							dir: "ltr",
							placeholder: "رقم أو معرف شام كاش",
							className: "field"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "المدينة / الحي",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							name: "city",
							required: true,
							placeholder: "حلب — الجميلية",
							className: "field"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "وصف مختصر للبضاعة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							name: "desc",
							rows: 3,
							placeholder: "جملة أقمشة تركي، نصف جملة متاح...",
							className: "field min-h-24"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الباقة المطلوبة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							name: "plan",
							className: "field",
							defaultValue: planQ === "weekly" ? "weekly" : "trial",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: "trial",
								children: [
									"تجربة ",
									settings.trialDays,
									" أيام مجانًا"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: "weekly",
								children: [
									"اشتراك أسبوعي — ",
									settings.weeklyPrice.toLocaleString("ar-SY"),
									" ل.س"
								]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "h-12 w-full rounded-xl bg-primary font-bold text-bg transition-transform active:scale-[0.96]",
						children: "إرسال طلب الانضمام"
					})
				]
			}),
			!sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactPay, {
					compact: true,
					waMessage: "مرحبا، أريد الانضمام إلى ريمون كتاجر"
				})
			}) : null
		]
	}) });
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-sm font-medium",
			children: label
		}), children]
	});
}
//#endregion
export { JoinPage as component };
