import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as Check, h as Copy } from "../_libs/lucide-react.mjs";
import { s as cn } from "./layout-B_Hq2xpR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/copy-row-BTEP3dAp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CopyRow({ label, value, copyValue, dir = "ltr", mono = false }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	if (!value) return null;
	async function copy() {
		try {
			await navigator.clipboard.writeText(copyValue || value);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 rounded-2xl bg-cream px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-faint",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				dir,
				className: cn("mt-0.5 break-all text-base font-semibold text-fg", mono && "font-mono text-sm tracking-wide"),
				children: value
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: copy,
			className: "inline-flex h-11 min-w-11 items-center justify-center gap-1 rounded-xl bg-surface px-3 text-sm font-medium text-fg shadow-card transition-transform duration-150 active:scale-[0.96]",
			"aria-label": `نسخ ${label}`,
			children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-wa" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "hidden sm:inline",
				children: copied ? "تم" : "نسخ"
			})]
		})]
	});
}
//#endregion
export { CopyRow as t };
