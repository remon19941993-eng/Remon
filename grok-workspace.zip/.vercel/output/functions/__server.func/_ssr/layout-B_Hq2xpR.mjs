import { b as require_jsx_runtime, d as useRouterState, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as BrickWall, c as Smartphone, m as CreditCard, o as Store, p as House, r as UserPlus, s as Sparkles, t as Wheat, u as Scissors, v as BookOpen } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/layout-B_Hq2xpR.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatSyp(n) {
	return `${n.toLocaleString("ar-SY")} ل.س`;
}
function toWaDigits(raw) {
	let digits = raw.replace(/\D/g, "");
	if (!digits) return "";
	if (digits.startsWith("00")) digits = digits.slice(2);
	if (digits.startsWith("963")) return digits;
	if (digits.startsWith("0")) return `963${digits.slice(1)}`;
	return `963${digits}`;
}
function waLink(phone, text) {
	const digits = toWaDigits(phone);
	if (!digits) return "";
	return `https://wa.me/${digits}?text=${encodeURIComponent(text)}`;
}
function displayPhone(raw) {
	const d = raw.replace(/\D/g, "");
	if (d.startsWith("00963") && d.length >= 13) {
		const rest = d.slice(5);
		return `00963 ${rest.slice(0, 3)} ${rest.slice(3, 6)} ${rest.slice(6)}`.trim();
	}
	if (d.startsWith("963") && d.length >= 11) {
		const rest = d.slice(3);
		return `+963 ${rest.slice(0, 3)} ${rest.slice(3, 6)} ${rest.slice(6)}`.trim();
	}
	if (d.length === 10 && d.startsWith("09")) return `${d.slice(0, 4)} ${d.slice(4, 7)} ${d.slice(7)}`;
	return raw;
}
var DEFAULT_SETTINGS = {
	shamCashAccount: "23fc82cc5eafb5bd9ac013ba252b8599",
	shamCashName: "إدارة ريمون",
	contactPhone: "00963942591022",
	weeklyPrice: 5e3,
	trialDays: 3
};
var CATEGORIES = [
	{
		id: "fabric",
		name: "أقمشة وملابس",
		blurb: "تركي وسوري — جملة ونصف جملة",
		image: "/images/cat-fabric.jpg",
		icon: Scissors
	},
	{
		id: "food",
		name: "مواد غذائية",
		blurb: "تموين للمولات والبقالات",
		image: "/images/cat-food.jpg",
		icon: Wheat
	},
	{
		id: "home",
		name: "أدوات منزلية",
		blurb: "مطبخ وتنظيف وبلاستيك",
		image: "/images/cat-home.jpg",
		icon: House
	},
	{
		id: "phone",
		name: "موبايلات",
		blurb: "إكسسوارات وفتح علب",
		image: "/images/cat-phone.jpg",
		icon: Smartphone
	},
	{
		id: "build",
		name: "مواد بناء",
		blurb: "إسمنت وحديد وإكساء",
		image: "/images/cat-build.jpg",
		icon: BrickWall
	},
	{
		id: "beauty",
		name: "تجميل",
		blurb: "كريمات وعطور ومكياج",
		image: "/images/cat-beauty.jpg",
		icon: Sparkles
	},
	{
		id: "office",
		name: "قرطاسية",
		blurb: "مكتبات ومدارس",
		image: "/images/cat-office.jpg",
		icon: BookOpen
	}
];
var CATEGORY_MAP = Object.fromEntries(CATEGORIES.map((c) => [c.id, c]));
var SEED_MERCHANTS = [
	{
		id: "sham-fabric",
		name: "مؤسسة الشام للأقمشة",
		category: "fabric",
		city: "حلب — الجميلية",
		desc: "جملة أقمشة تركي وسوري، نصف جملة متاح للمحلات والمشاغل.",
		phone: "0944000001",
		shamCash: "",
		plan: "weekly",
		tags: [
			"أقمشة",
			"أواشن",
			"تريكو"
		],
		cover: "/images/cat-fabric.jpg",
		products: [
			{
				id: "sf1",
				name: "قماش أواشن تركي",
				unit: "متر",
				minQty: 50,
				wholesalePrice: 18500,
				image: "/images/prod-fabric.jpg"
			},
			{
				id: "sf2",
				name: "تريكو شتوي",
				unit: "متر",
				minQty: 40,
				wholesalePrice: 22e3,
				image: "/images/prod-fabric.jpg"
			},
			{
				id: "sf3",
				name: "قطن سوري مشط",
				unit: "متر",
				minQty: 30,
				wholesalePrice: 14200,
				image: "/images/cat-fabric.jpg"
			},
			{
				id: "sf4",
				name: "شيفون سهرة",
				unit: "متر",
				minQty: 20,
				wholesalePrice: 31e3,
				image: "/images/prod-fabric.jpg"
			}
		]
	},
	{
		id: "golden-mobile",
		name: "تاجر الموبايل الذهبي",
		category: "phone",
		city: "حلب — العزيزية",
		desc: "جملة إكسسوارات وموبايلات مستعملة وفتح علب.",
		phone: "0944000002",
		shamCash: "",
		plan: "weekly",
		tags: [
			"موبايل",
			"سماعات",
			"كفرات"
		],
		cover: "/images/cat-phone.jpg",
		products: [
			{
				id: "gm1",
				name: "كفر سيليكون تشكيلة",
				unit: "دستة",
				minQty: 10,
				wholesalePrice: 45e3,
				image: "/images/cat-phone.jpg"
			},
			{
				id: "gm2",
				name: "سماعات بلوتوث",
				unit: "قطعة",
				minQty: 12,
				wholesalePrice: 38e3,
				image: "/images/cat-phone.jpg"
			},
			{
				id: "gm3",
				name: "شاحن سريع 25W",
				unit: "قطعة",
				minQty: 20,
				wholesalePrice: 27500,
				image: "/images/cat-electro.jpg"
			},
			{
				id: "gm4",
				name: "كابل Type-C جملة",
				unit: "دستة",
				minQty: 5,
				wholesalePrice: 32e3,
				image: "/images/cat-electro.jpg"
			}
		]
	},
	{
		id: "modern-food",
		name: "الغذائية الحديثة",
		category: "food",
		city: "حلب — السليمانية",
		desc: "مواد تموينية جملة للمولات والبقالات.",
		phone: "0944000003",
		shamCash: "",
		plan: "weekly",
		tags: [
			"أرز",
			"زيت",
			"معلبات"
		],
		cover: "/images/cat-food.jpg",
		products: [
			{
				id: "mf1",
				name: "أرز مصري كيس 25 كغ",
				unit: "كيس",
				minQty: 10,
				wholesalePrice: 185e3,
				image: "/images/cat-food.jpg"
			},
			{
				id: "mf2",
				name: "زيت دوار الشمس 4 لتر",
				unit: "صفيحة",
				minQty: 12,
				wholesalePrice: 72e3,
				image: "/images/cat-food.jpg"
			},
			{
				id: "mf3",
				name: "سكر ناعم كيس 50 كغ",
				unit: "كيس",
				minQty: 5,
				wholesalePrice: 21e4,
				image: "/images/cat-food.jpg"
			},
			{
				id: "mf4",
				name: "معلبات تشكيلة كرتون",
				unit: "كرتون",
				minQty: 8,
				wholesalePrice: 54e3,
				image: "/images/cat-food.jpg"
			}
		]
	},
	{
		id: "house-tools",
		name: "بيت الأدوات",
		category: "home",
		city: "حلب — الباب",
		desc: "أدوات مطبخ ومنزل نصف جملة.",
		phone: "0944000004",
		shamCash: "",
		plan: "trial",
		tags: [
			"أواني",
			"بلاستيك",
			"تنظيف"
		],
		cover: "/images/cat-home.jpg",
		products: [
			{
				id: "ht1",
				name: "طقم قدور ستانلس",
				unit: "طقم",
				minQty: 6,
				wholesalePrice: 125e3,
				image: "/images/cat-home.jpg"
			},
			{
				id: "ht2",
				name: "أحواض بلاستيك",
				unit: "دستة",
				minQty: 4,
				wholesalePrice: 28e3,
				image: "/images/cat-home.jpg"
			},
			{
				id: "ht3",
				name: "مكنسة ومنفضة جملة",
				unit: "كرتون",
				minQty: 5,
				wholesalePrice: 41e3,
				image: "/images/cat-home.jpg"
			}
		]
	},
	{
		id: "electro-aleppo",
		name: "إلكترو حلب",
		category: "phone",
		city: "حلب — الفرقان",
		desc: "شاشات وإكسسوارات جملة.",
		phone: "0944000005",
		shamCash: "",
		plan: "weekly",
		tags: [
			"شاشات",
			"شواحن",
			"كابلات"
		],
		cover: "/images/cat-electro.jpg",
		products: [
			{
				id: "ea1",
				name: "شاشة 32 بوصة جملة",
				unit: "قطعة",
				minQty: 3,
				wholesalePrice: 89e4,
				image: "/images/cat-electro.jpg"
			},
			{
				id: "ea2",
				name: "شاحن جداري أصلي طراز",
				unit: "قطعة",
				minQty: 20,
				wholesalePrice: 19500,
				image: "/images/cat-phone.jpg"
			},
			{
				id: "ea3",
				name: "كابل HDMI 2م",
				unit: "دستة",
				minQty: 5,
				wholesalePrice: 36e3,
				image: "/images/cat-electro.jpg"
			}
		]
	},
	{
		id: "nour-beauty",
		name: "مستحضرات نور",
		category: "beauty",
		city: "حلب — الجديدة",
		desc: "تجميل وعناية بالجملة للمحلات.",
		phone: "0944000006",
		shamCash: "",
		plan: "weekly",
		tags: [
			"كريمات",
			"عطور",
			"مكياج"
		],
		cover: "/images/cat-beauty.jpg",
		products: [
			{
				id: "nb1",
				name: "كريم مرطب علبة 12",
				unit: "كرتون",
				minQty: 4,
				wholesalePrice: 64e3,
				image: "/images/cat-beauty.jpg"
			},
			{
				id: "nb2",
				name: "عطر حجم 100مل",
				unit: "قطعة",
				minQty: 12,
				wholesalePrice: 28e3,
				image: "/images/cat-beauty.jpg"
			},
			{
				id: "nb3",
				name: "باليت مكياج جملة",
				unit: "قطعة",
				minQty: 10,
				wholesalePrice: 22500,
				image: "/images/cat-beauty.jpg"
			}
		]
	},
	{
		id: "aleppo-build",
		name: "مستودعات حلب للبناء",
		category: "build",
		city: "حلب — الشيخ نجار",
		desc: "إسمنت وحديد وإكساء للمقاولين والمحلات.",
		phone: "0944000007",
		shamCash: "",
		plan: "weekly",
		tags: [
			"إسمنت",
			"حديد",
			"بلاط"
		],
		cover: "/images/cat-build.jpg",
		products: [
			{
				id: "ab1",
				name: "إسمنت كيس 50 كغ",
				unit: "كيس",
				minQty: 50,
				wholesalePrice: 42e3,
				image: "/images/cat-build.jpg"
			},
			{
				id: "ab2",
				name: "حديد تسليح طن",
				unit: "طن",
				minQty: 1,
				wholesalePrice: 42e5,
				image: "/images/cat-build.jpg"
			},
			{
				id: "ab3",
				name: "بلاط أرضيات كرتون",
				unit: "متر",
				minQty: 40,
				wholesalePrice: 18500,
				image: "/images/cat-build.jpg"
			}
		]
	},
	{
		id: "nour-office",
		name: "قرطاسية النور",
		category: "office",
		city: "حلب — العزيزية",
		desc: "قرطاسية ومدارس جملة للمكتبات.",
		phone: "0944000008",
		shamCash: "",
		plan: "trial",
		tags: [
			"دفاتر",
			"أقلام",
			"حقائب"
		],
		cover: "/images/cat-office.jpg",
		products: [
			{
				id: "no1",
				name: "دفتر 80 ورقة كرتون",
				unit: "كرتون",
				minQty: 5,
				wholesalePrice: 48e3,
				image: "/images/cat-office.jpg"
			},
			{
				id: "no2",
				name: "أقلام جاف دستة",
				unit: "دستة",
				minQty: 20,
				wholesalePrice: 8500,
				image: "/images/cat-office.jpg"
			},
			{
				id: "no3",
				name: "حقيبة مدرسية",
				unit: "قطعة",
				minQty: 10,
				wholesalePrice: 35e3,
				image: "/images/cat-office.jpg"
			}
		]
	}
];
var CATEGORY_SELECT = [...CATEGORIES.map((c) => ({
	id: c.id,
	name: c.name
})), {
	id: "other",
	name: "أخرى"
}];
var ADMIN_USER = "مؤسس";
var ADMIN_PASS = "admin123";
var useRemonStore = create()(persist((set, get) => ({
	settings: DEFAULT_SETTINGS,
	merchants: SEED_MERCHANTS,
	requests: [],
	adminAuthed: false,
	updateSettings: (patch) => set({ settings: {
		...get().settings,
		...patch
	} }),
	addRequest: (req) => {
		const row = {
			...req,
			id: `req-${Date.now()}`,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set({ requests: [row, ...get().requests] });
		return row;
	},
	removeRequest: (id) => set({ requests: get().requests.filter((r) => r.id !== id) }),
	upsertMerchant: (m) => {
		const list = get().merchants;
		const i = list.findIndex((x) => x.id === m.id);
		if (i >= 0) {
			const next = list.slice();
			next[i] = m;
			set({ merchants: next });
		} else set({ merchants: [m, ...list] });
	},
	removeMerchant: (id) => set({ merchants: get().merchants.filter((m) => m.id !== id) }),
	loginAdmin: (user, pass) => {
		const ok = user.trim() === "مؤسس" && pass === "admin123";
		if (ok) set({ adminAuthed: true });
		return ok;
	},
	logoutAdmin: () => set({ adminAuthed: false })
}), {
	name: "remon-market-v1",
	partialize: (s) => ({
		settings: s.settings,
		merchants: s.merchants,
		requests: s.requests
	}),
	merge: (persisted, current) => {
		const p = persisted ?? {};
		return {
			...current,
			...p,
			settings: {
				...DEFAULT_SETTINGS,
				...p.settings,
				shamCashAccount: p.settings?.shamCashAccount || DEFAULT_SETTINGS.shamCashAccount,
				contactPhone: p.settings?.contactPhone || DEFAULT_SETTINGS.contactPhone
			},
			merchants: p.merchants?.length ? p.merchants : current.merchants
		};
	}
}));
function useMerchant(id) {
	return useRemonStore((s) => s.merchants.find((m) => m.id === id));
}
var NAV = [
	{
		to: "/",
		label: "الرئيسية",
		icon: House
	},
	{
		to: "/merchants",
		label: "التجار",
		icon: Store
	},
	{
		to: "/plans",
		label: "اشتراك",
		icon: CreditCard
	},
	{
		to: "/join",
		label: "انضم",
		icon: UserPlus
	}
];
function Shell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const settings = useRemonStore((s) => s.settings);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-ink px-4 py-2 text-center text-xs text-cream",
				children: ["منصة احترافية لتجار سوريا — الاشتراك عبر شام كاش", settings.contactPhone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mx-2 hidden sm:inline",
					dir: "ltr",
					children: ["· ", displayPhone(settings.contactPhone)]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border bg-surface/95 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-10 items-center justify-center rounded-xl bg-linear-to-br from-gold to-gold-deep text-lg font-bold text-white shadow-card",
								children: "R"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "leading-tight",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block font-bold text-fg",
									children: ["ريمون ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-medium text-gold-deep",
										children: "Remon"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-[10px] text-faint",
									children: "سوق التجار"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "hidden items-center gap-1 sm:flex",
							children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: item.to,
								className: cn("rounded-lg px-3 py-2 text-sm transition-colors", pathname === item.to ? "bg-cream font-medium text-fg" : "text-muted hover:bg-cream hover:text-fg"),
								children: item.label
							}, item.to))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/join",
							className: "hidden h-10 items-center rounded-xl bg-primary px-4 text-sm font-medium text-bg sm:inline-flex",
							children: "سجّل متجرك"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "pb-24 sm:pb-0",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-16 bg-ink text-cream",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold text-white",
							children: "ريمون — سوق التجار"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-faint",
							children: "منصة محلية على نموذج علي بابا: التاجر يشترك، يعرض بضاعته، والزبون يتواصل مباشرة."
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold text-white",
									children: "حساب شام كاش"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									dir: "ltr",
									className: "mt-2 break-all font-mono text-gold",
									children: settings.shamCashAccount
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-faint",
									children: settings.shamCashName
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold text-white",
									children: "رقم التواصل"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									dir: "ltr",
									className: "mt-2 text-gold",
									children: displayPhone(settings.contactPhone)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/admin",
									className: "mt-3 inline-block text-xs text-faint hover:text-cream",
									children: "لوحة الإدارة"
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t border-white/10 py-4 text-center text-xs text-faint",
					children: "© 2026 Remon — ريمون. سوق التجار السوري. وسيط عرض غير مسؤول عن الاتفاقات بين الأطراف."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-40 grid grid-cols-4 border-t border-border bg-surface sm:hidden",
				children: NAV.map((item) => {
					const Icon = item.icon;
					const on = pathname === item.to;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						className: cn("flex h-16 flex-col items-center justify-center gap-1 text-[11px]", on ? "font-bold text-fg" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
					}, item.to);
				})
			})
		]
	});
}
//#endregion
export { CATEGORY_SELECT as a, displayPhone as c, useRemonStore as d, waLink as f, CATEGORY_MAP as i, formatSyp as l, ADMIN_USER as n, Shell as o, CATEGORIES as r, cn as s, ADMIN_PASS as t, useMerchant as u };
