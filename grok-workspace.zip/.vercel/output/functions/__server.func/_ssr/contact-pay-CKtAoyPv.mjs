import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as MessageCircle, n as Wallet } from "../_libs/lucide-react.mjs";
import { c as displayPhone, d as useRemonStore, f as waLink } from "./layout-B_Hq2xpR.mjs";
import { t as CopyRow } from "./copy-row-BTEP3dAp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-pay-CKtAoyPv.js
var import_jsx_runtime = require_jsx_runtime();
function ContactPay({ compact = false, waMessage = "مرحبا، تواصل من منصة ريمون" }) {
	const settings = useRemonStore((s) => s.settings);
	const wa = waLink(settings.contactPhone, waMessage);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: compact ? "rounded-2xl bg-surface p-4 shadow-card" : "rounded-[1.5rem] bg-surface p-5 shadow-card sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-10 items-center justify-center rounded-xl bg-gold/20 text-gold-deep",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-bold text-fg",
					children: "حساب شام كاش ورقم التواصل"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: settings.shamCashName
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
					label: "حساب شام كاش",
					value: settings.shamCashAccount,
					mono: true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
					label: "رقم التواصل",
					value: displayPhone(settings.contactPhone) || settings.contactPhone,
					copyValue: settings.contactPhone
				})]
			}),
			wa ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: wa,
				target: "_blank",
				rel: "noreferrer",
				className: "mt-4 flex h-12 items-center justify-center gap-2 rounded-xl bg-wa text-sm font-bold text-white transition-colors hover:bg-wa-hover active:scale-[0.96]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), "واتساب — تواصل مع ريمون"]
			}) : null
		]
	});
}
//#endregion
export { ContactPay as t };
