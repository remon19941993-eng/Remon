import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as useRemonStore, n as ADMIN_USER, o as Shell, t as ADMIN_PASS } from "./layout-B_Hq2xpR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-B_osXvWg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminPage() {
	const authed = useRemonStore((s) => s.adminAuthed);
	const login = useRemonStore((s) => s.loginAdmin);
	const logout = useRemonStore((s) => s.logoutAdmin);
	const settings = useRemonStore((s) => s.settings);
	const updateSettings = useRemonStore((s) => s.updateSettings);
	const requests = useRemonStore((s) => s.requests);
	const removeRequest = useRemonStore((s) => s.removeRequest);
	const merchants = useRemonStore((s) => s.merchants);
	const upsertMerchant = useRemonStore((s) => s.upsertMerchant);
	const [err, setErr] = (0, import_react.useState)("");
	if (!authed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mx-auto mt-16 max-w-sm space-y-4 rounded-[1.25rem] bg-surface p-5 shadow-card",
		onSubmit: (e) => {
			e.preventDefault();
			const fd = new FormData(e.currentTarget);
			const ok = login(String(fd.get("user")), String(fd.get("pass")));
			setErr(ok ? "" : "بيانات الدخول غير صحيحة");
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-center text-xl font-bold",
				children: "لوحة الإدارة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm",
				children: ["اسم المستخدم", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "user",
					className: "field mt-1",
					autoComplete: "username"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm",
				children: ["كلمة المرور", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "pass",
					type: "password",
					className: "field mt-1",
					autoComplete: "current-password"
				})]
			}),
			err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-red-700",
				children: err
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "h-11 w-full rounded-xl bg-primary font-bold text-bg",
				children: "دخول"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-center text-xs text-faint",
				children: [
					"للمعاينة: ",
					ADMIN_USER,
					" / ",
					ADMIN_PASS
				]
			})
		]
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-8 px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold",
					children: "لوحة ريمون"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: logout,
					className: "text-sm text-muted",
					children: "خروج"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[1.25rem] bg-surface p-5 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-bold",
					children: "حساب شام كاش ورقم التواصل"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm",
							children: ["حساب شام كاش", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								dir: "ltr",
								className: "field mt-1 font-mono",
								value: settings.shamCashAccount,
								onChange: (e) => updateSettings({ shamCashAccount: e.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm",
							children: ["اسم الحساب", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mt-1",
								value: settings.shamCashName,
								onChange: (e) => updateSettings({ shamCashName: e.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm",
							children: ["رقم التواصل", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								dir: "ltr",
								className: "field mt-1",
								value: settings.contactPhone,
								onChange: (e) => updateSettings({ contactPhone: e.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm",
							children: ["الاشتراك الأسبوعي (ل.س)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								className: "field mt-1",
								value: settings.weeklyPrice,
								onChange: (e) => updateSettings({ weeklyPrice: Number(e.target.value) || 0 })
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[1.25rem] bg-surface p-5 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-bold",
					children: [
						"طلبات الانضمام (",
						requests.length,
						")"
					]
				}), requests.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "لا توجد طلبات جديدة."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-3",
					children: requests.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl bg-cream p-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold",
								children: r.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 text-muted",
								children: [
									r.city,
									" · ",
									r.phone,
									r.shamCash ? ` · شام كاش ${r.shamCash}` : ""
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-muted",
								children: r.desc
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "mt-2 text-xs text-faint",
								onClick: () => removeRequest(r.id),
								children: "حذف"
							})
						]
					}, r.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[1.25rem] bg-surface p-5 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-bold",
					children: [
						"التجار (",
						merchants.length,
						")"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2",
					children: merchants.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 rounded-xl bg-cream px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-medium",
							children: m.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted",
							dir: "ltr",
							children: [
								m.plan === "weekly" ? "مشترك" : "تجربة",
								" · ",
								m.phone
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-xs",
							onClick: () => upsertMerchant({
								...m,
								plan: m.plan === "weekly" ? "trial" : "weekly"
							}),
							children: "تبديل الباقة"
						})]
					}, m.id))
				})]
			})
		]
	}) });
}
//#endregion
export { AdminPage as component };
