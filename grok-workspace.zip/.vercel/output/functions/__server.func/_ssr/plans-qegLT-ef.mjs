import { b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as Check } from "../_libs/lucide-react.mjs";
import { d as useRemonStore, f as waLink, l as formatSyp, o as Shell } from "./layout-B_Hq2xpR.mjs";
import { t as ContactPay } from "./contact-pay-CKtAoyPv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/plans-qegLT-ef.js
var import_jsx_runtime = require_jsx_runtime();
function PlansPage() {
	const settings = useRemonStore((s) => s.settings);
	const payWa = waLink(settings.contactPhone, `مرحبا، تم تحويل اشتراك ريمون إلى شام كاش\nالحساب: ${settings.shamCashAccount}\nاسم المتجر: `);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-center text-2xl font-bold",
				children: "الاشتراك في ريمون"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mx-auto mt-2 max-w-md text-center text-sm text-muted",
				children: [
					settings.trialDays,
					" أيام تجربة مجانية، بعدها ",
					formatSyp(settings.weeklyPrice),
					" أسبوعيًا عبر شام كاش"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto mt-10 grid max-w-2xl gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-[1.25rem] bg-surface p-6 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-center text-xs font-bold text-faint",
							children: "للبدء"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1 text-center text-lg font-bold",
							children: "تجربة مجانية"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "my-4 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-3xl font-bold",
								children: "مجانًا"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 text-sm text-muted",
								children: [settings.trialDays, " أيام"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mb-6 space-y-2 text-sm text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Li, { children: "ظهور متجرك في الدليل" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Li, { children: "زر تواصل واتساب" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Li, { children: "بدون دفع مقدمًا" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/join",
							search: { plan: "trial" },
							className: "flex h-11 items-center justify-center rounded-xl bg-cream font-medium",
							children: "ابدأ التجربة"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-[1.25rem] bg-surface p-6 shadow-card ring-2 ring-gold",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-center text-xs font-bold text-gold-deep",
							children: "بعد التجربة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1 text-center text-lg font-bold",
							children: "اشتراك أسبوعي"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "my-4 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-3xl font-bold tabular-nums",
								children: settings.weeklyPrice.toLocaleString("ar-SY")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: " ل.س / أسبوعيًا"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mb-6 space-y-2 text-sm text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Li, { children: "بقاء الظهور في المنصة" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Li, { children: "شارة مشترك نشط" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Li, { children: "الدفع عبر شام كاش" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Li, { children: "تجديد كل أسبوع" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/join",
							search: { plan: "weekly" },
							className: "flex h-11 items-center justify-center rounded-xl bg-linear-to-l from-gold to-gold-deep font-bold text-ink",
							children: "اشترك الآن"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto mt-10 max-w-lg space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactPay, { waMessage: `مرحبا، تم تحويل اشتراك ريمون. اسم المتجر: ` }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-center text-xs leading-relaxed text-muted",
						children: [
							"التجربة: ",
							settings.trialDays,
							" أيام مجانًا. بعدها حوّل ",
							formatSyp(settings.weeklyPrice),
							" أسبوعيًا إلى حساب شام كاش، ثم أرسل صورة الإشعار مع اسم متجرك عبر واتساب لتجديد الاشتراك."
						]
					}),
					payWa ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: payWa,
						target: "_blank",
						rel: "noreferrer",
						className: "flex h-12 items-center justify-center rounded-xl bg-wa font-bold text-white hover:bg-wa-hover",
						children: "تأكيد الدفع عبر واتساب"
					}) : null
				]
			})
		]
	}) });
}
function Li({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 shrink-0 text-gold-deep" }), children]
	});
}
//#endregion
export { PlansPage as component };
