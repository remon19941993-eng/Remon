import { b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as ArrowRight, d as MessageCircle, f as MapPin, n as Wallet } from "../_libs/lucide-react.mjs";
import { c as displayPhone, f as waLink, i as CATEGORY_MAP, l as formatSyp, o as Shell, u as useMerchant } from "./layout-B_Hq2xpR.mjs";
import { n as Route } from "./router-DN13VJYe.mjs";
import { t as CopyRow } from "./copy-row-BTEP3dAp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/merchants._id-DoEs5TYT.js
var import_jsx_runtime = require_jsx_runtime();
function MerchantPage() {
	const { id } = Route.useParams();
	const merchant = useMerchant(id);
	if (!merchant) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg px-4 py-20 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-xl font-bold",
			children: "التاجر غير موجود"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/merchants",
			className: "mt-4 inline-block text-sm text-muted",
			children: "العودة للدليل"
		})]
	}) });
	const cat = CATEGORY_MAP[merchant.category];
	const wa = waLink(merchant.phone, `مرحبا، شفت متجر ${merchant.name} على ريمون وأريد الاستفسار عن البضاعة`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-52 overflow-hidden md:h-72",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: merchant.cover,
				alt: "",
				className: "size-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-ink via-ink/30 to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-x-0 bottom-0 mx-auto max-w-6xl px-4 pb-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/merchants",
						className: "mb-3 inline-flex items-center gap-1 text-sm text-cream",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" }), "الدليل"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-bold text-white md:text-3xl",
						children: merchant.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 flex items-center gap-1 text-sm text-cream/80",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }),
							merchant.city,
							" · ",
							cat?.name
						]
					})
				]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-6xl gap-6 px-4 py-8 lg:grid-cols-[1fr_320px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "leading-relaxed text-muted",
				children: merchant.desc
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: merchant.tags.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-cream px-3 py-1 text-xs text-muted",
					children: t
				}, t))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 mb-4 text-lg font-bold",
				children: "بضاعة الجملة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: merchant.products.map((p) => {
					const pWa = waLink(merchant.phone, `مرحبا، أريد طلب جملة من ريمون:\nالمنتج: ${p.name}\nالحد الأدنى: ${p.minQty} ${p.unit}`);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "overflow-hidden rounded-2xl bg-surface shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: p.image,
							alt: "",
							className: "h-36 w-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-bold",
									children: p.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted",
									children: [
										"من ",
										p.minQty,
										" ",
										p.unit
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 font-bold text-gold-deep tabular-nums",
									children: [formatSyp(p.wholesalePrice), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mr-1 text-xs font-medium text-faint",
										children: ["/ ", p.unit]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: pWa,
									target: "_blank",
									rel: "noreferrer",
									className: "mt-3 flex h-11 items-center justify-center gap-1.5 rounded-xl bg-primary text-sm font-medium text-bg",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), "اطلب عبر واتساب"]
								})
							]
						})]
					}, p.id);
				})
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "space-y-3 lg:sticky lg:top-24 lg:self-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[1.25rem] bg-surface p-4 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-3 font-bold",
						children: "تواصل مع التاجر"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
						label: "رقم التواصل",
						value: displayPhone(merchant.phone),
						copyValue: merchant.phone
					}),
					merchant.shamCash ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyRow, {
							label: "شام كاش التاجر",
							value: merchant.shamCash,
							mono: true
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: wa,
						target: "_blank",
						rel: "noreferrer",
						className: "mt-3 flex h-12 items-center justify-center gap-2 rounded-xl bg-wa font-bold text-white hover:bg-wa-hover",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), "واتساب"]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-start gap-2 text-xs leading-relaxed text-faint",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "mt-0.5 size-3.5 shrink-0" }), "الاتفاق والدفع مباشرة بينك وبين التاجر. ريمون وسيط عرض فقط."]
			})]
		})]
	})] });
}
//#endregion
export { MerchantPage as component };
