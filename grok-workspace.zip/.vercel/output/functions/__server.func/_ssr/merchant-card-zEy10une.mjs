import { b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as MessageCircle, f as MapPin } from "../_libs/lucide-react.mjs";
import { f as waLink, i as CATEGORY_MAP, s as cn } from "./layout-B_Hq2xpR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/merchant-card-zEy10une.js
var import_jsx_runtime = require_jsx_runtime();
function MerchantCard({ merchant }) {
	const cat = CATEGORY_MAP[merchant.category];
	const wa = waLink(merchant.phone, `مرحبا، شفت متج ${merchant.name} على ريمون وأريد الاستفسار عن البضاعة`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group flex flex-col overflow-hidden rounded-[1.25rem] bg-surface shadow-card transition-[box-shadow,transform] duration-200 hover:shadow-card-hover",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/merchants/$id",
			params: { id: merchant.id },
			className: "relative block aspect-[16/10] overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: merchant.cover,
					alt: "",
					className: "size-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-ink/70 to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("absolute top-3 right-3 rounded-full px-2.5 py-1 text-[10px] font-bold", merchant.plan === "weekly" ? "bg-gold text-ink" : "bg-cream text-muted"),
					children: merchant.plan === "weekly" ? "مشترك" : "تجربة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute bottom-3 right-3 text-xs font-medium text-white",
					children: cat?.name
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/merchants/$id",
					params: { id: merchant.id },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-bold leading-snug text-fg",
						children: merchant.name
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 flex items-center gap-1 text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }), merchant.city]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 line-clamp-2 flex-1 text-sm text-muted",
					children: merchant.desc
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-faint",
					children: merchant.tags.join(" · ")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/merchants/$id",
						params: { id: merchant.id },
						className: "flex h-11 items-center justify-center rounded-xl bg-cream text-sm font-medium text-fg transition-transform active:scale-[0.96]",
						children: "البضاعة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: wa,
						target: "_blank",
						rel: "noreferrer",
						className: "flex h-11 items-center justify-center gap-1.5 rounded-xl bg-primary text-sm font-medium text-bg transition-transform active:scale-[0.96]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), "واتساب"]
					})]
				})
			]
		})]
	});
}
//#endregion
export { MerchantCard as t };
