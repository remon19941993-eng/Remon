import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as Search } from "../_libs/lucide-react.mjs";
import { d as useRemonStore, o as Shell, r as CATEGORIES, s as cn } from "./layout-B_Hq2xpR.mjs";
import { r as Route$2 } from "./router-DN13VJYe.mjs";
import { t as MerchantCard } from "./merchant-card-zEy10une.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/merchants-CKd0CEo4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MerchantsPage() {
	const { cat, q } = Route$2.useSearch();
	const navigate = Route$2.useNavigate();
	const merchants = useRemonStore((s) => s.merchants);
	const [query, setQuery] = (0, import_react.useState)(q ?? "");
	const active = cat ?? "all";
	const list = (0, import_react.useMemo)(() => {
		const needle = query.trim();
		return merchants.filter((m) => active === "all" ? true : m.category === active).filter((m) => {
			if (!needle) return true;
			return `${m.name} ${m.city} ${m.desc} ${m.tags.join(" ")}`.includes(needle);
		}).slice().sort((a, b) => Number(b.plan === "weekly") - Number(a.plan === "weekly"));
	}, [
		merchants,
		active,
		query
	]);
	function setCat(id) {
		navigate({ search: {
			cat: id === "all" ? void 0 : id,
			q: query || void 0
		} });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold",
				children: "دليل التجار"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "ابحث حسب التصنيف أو الاسم"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "relative mt-6 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-faint" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "اسم التاجر أو البضاعة...",
					className: "h-12 w-full rounded-2xl bg-surface pr-10 pl-4 shadow-card outline-none focus:ring-2 focus:ring-gold/50"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					on: active === "all",
					onClick: () => setCat("all"),
					children: "الكل"
				}), CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					on: active === c.id,
					onClick: () => setCat(c.id),
					children: c.name
				}, c.id))]
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-16 text-center text-muted",
				children: "لا يوجد تجار في هذا التصنيف بعد."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: list.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MerchantCard, { merchant: m }, m.id))
			})
		]
	}) });
}
function FilterChip({ on, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-10 rounded-full px-3.5 text-sm transition-colors", on ? "bg-primary text-bg" : "bg-surface text-muted shadow-card"),
		children
	});
}
//#endregion
export { MerchantsPage as component };
