import type { CategoryId, Merchant, SiteSettings } from "./types";
import {
  BookOpen,
  BrickWall,
  House,
  Scissors,
  Smartphone,
  Sparkles,
  Wheat,
  type LucideIcon,
} from "lucide-react";

export const DEFAULT_SETTINGS: SiteSettings = {
  shamCashAccount: "23fc82cc5eafb5bd9ac013ba252b8599",
  shamCashName: "إدارة ريمون",
  contactPhone: "00963942591022",
  weeklyPrice: 5000,
  trialDays: 3,
};

export const CATEGORIES: {
  id: CategoryId;
  name: string;
  blurb: string;
  image: string;
  icon: LucideIcon;
}[] = [
  {
    id: "fabric",
    name: "أقمشة وملابس",
    blurb: "تركي وسوري — جملة ونصف جملة",
    image: "/images/cat-fabric.jpg",
    icon: Scissors,
  },
  {
    id: "food",
    name: "مواد غذائية",
    blurb: "تموين للمولات والبقالات",
    image: "/images/cat-food.jpg",
    icon: Wheat,
  },
  {
    id: "home",
    name: "أدوات منزلية",
    blurb: "مطبخ وتنظيف وبلاستيك",
    image: "/images/cat-home.jpg",
    icon: House,
  },
  {
    id: "phone",
    name: "موبايلات",
    blurb: "إكسسوارات وفتح علب",
    image: "/images/cat-phone.jpg",
    icon: Smartphone,
  },
  {
    id: "build",
    name: "مواد بناء",
    blurb: "إسمنت وحديد وإكساء",
    image: "/images/cat-build.jpg",
    icon: BrickWall,
  },
  {
    id: "beauty",
    name: "تجميل",
    blurb: "كريمات وعطور ومكياج",
    image: "/images/cat-beauty.jpg",
    icon: Sparkles,
  },
  {
    id: "office",
    name: "قرطاسية",
    blurb: "مكتبات ومدارس",
    image: "/images/cat-office.jpg",
    icon: BookOpen,
  },
];

export const CATEGORY_MAP = Object.fromEntries(
  CATEGORIES.map((c) => [c.id, c]),
) as Record<CategoryId, (typeof CATEGORIES)[number]>;

export const SEED_MERCHANTS: Merchant[] = [
  {
    id: "sham-fabric",
    name: "مؤسسة الشام للأقمشة",
    category: "fabric",
    city: "حلب — الجميلية",
    desc: "جملة أقمشة تركي وسوري، نصف جملة متاح للمحلات والمشاغل.",
    phone: "0944000001",
    shamCash: "",
    plan: "weekly",
    tags: ["أقمشة", "أواشن", "تريكو"],
    cover: "/images/cat-fabric.jpg",
    products: [
      { id: "sf1", name: "قماش أواشن تركي", unit: "متر", minQty: 50, wholesalePrice: 18500, image: "/images/prod-fabric.jpg" },
      { id: "sf2", name: "تريكو شتوي", unit: "متر", minQty: 40, wholesalePrice: 22000, image: "/images/prod-fabric.jpg" },
      { id: "sf3", name: "قطن سوري مشط", unit: "متر", minQty: 30, wholesalePrice: 14200, image: "/images/cat-fabric.jpg" },
      { id: "sf4", name: "شيفون سهرة", unit: "متر", minQty: 20, wholesalePrice: 31000, image: "/images/prod-fabric.jpg" },
    ],
  },
  {
    id: "golden-mobile",
    name: "تاجر الموبايل الذهبي",
    category: "phone",
    city: "حلب — العزيزية",
    desc: "جملة إكسسوارات وموبايلات مستعملة وفتح علب.",
    phone: "0944000002",
    shamCash: "",
    plan: "weekly",
    tags: ["موبايل", "سماعات", "كفرات"],
    cover: "/images/cat-phone.jpg",
    products: [
      { id: "gm1", name: "كفر سيليكون تشكيلة", unit: "دستة", minQty: 10, wholesalePrice: 45000, image: "/images/cat-phone.jpg" },
      { id: "gm2", name: "سماعات بلوتوث", unit: "قطعة", minQty: 12, wholesalePrice: 38000, image: "/images/cat-phone.jpg" },
      { id: "gm3", name: "شاحن سريع 25W", unit: "قطعة", minQty: 20, wholesalePrice: 27500, image: "/images/cat-electro.jpg" },
      { id: "gm4", name: "كابل Type-C جملة", unit: "دستة", minQty: 5, wholesalePrice: 32000, image: "/images/cat-electro.jpg" },
    ],
  },
  {
    id: "modern-food",
    name: "الغذائية الحديثة",
    category: "food",
    city: "حلب — السليمانية",
    desc: "مواد تموينية جملة للمولات والبقالات.",
    phone: "0944000003",
    shamCash: "",
    plan: "weekly",
    tags: ["أرز", "زيت", "معلبات"],
    cover: "/images/cat-food.jpg",
    products: [
      { id: "mf1", name: "أرز مصري كيس 25 كغ", unit: "كيس", minQty: 10, wholesalePrice: 185000, image: "/images/cat-food.jpg" },
      { id: "mf2", name: "زيت دوار الشمس 4 لتر", unit: "صفيحة", minQty: 12, wholesalePrice: 72000, image: "/images/cat-food.jpg" },
      { id: "mf3", name: "سكر ناعم كيس 50 كغ", unit: "كيس", minQty: 5, wholesalePrice: 210000, image: "/images/cat-food.jpg" },
      { id: "mf4", name: "معلبات تشكيلة كرتون", unit: "كرتون", minQty: 8, wholesalePrice: 54000, image: "/images/cat-food.jpg" },
    ],
  },
  {
    id: "house-tools",
    name: "بيت الأدوات",
    category: "home",
    city: "حلب — الباب",
    desc: "أدوات مطبخ ومنزل نصف جملة.",
    phone: "0944000004",
    shamCash: "",
    plan: "trial",
    tags: ["أواني", "بلاستيك", "تنظيف"],
    cover: "/images/cat-home.jpg",
    products: [
      { id: "ht1", name: "طقم قدور ستانلس", unit: "طقم", minQty: 6, wholesalePrice: 125000, image: "/images/cat-home.jpg" },
      { id: "ht2", name: "أحواض بلاستيك", unit: "دستة", minQty: 4, wholesalePrice: 28000, image: "/images/cat-home.jpg" },
      { id: "ht3", name: "مكنسة ومنفضة جملة", unit: "كرتون", minQty: 5, wholesalePrice: 41000, image: "/images/cat-home.jpg" },
    ],
  },
  {
    id: "electro-aleppo",
    name: "إلكترو حلب",
    category: "phone",
    city: "حلب — الفرقان",
    desc: "شاشات وإكسسوارات جملة.",
    phone: "0944000005",
    shamCash: "",
    plan: "weekly",
    tags: ["شاشات", "شواحن", "كابلات"],
    cover: "/images/cat-electro.jpg",
    products: [
      { id: "ea1", name: "شاشة 32 بوصة جملة", unit: "قطعة", minQty: 3, wholesalePrice: 890000, image: "/images/cat-electro.jpg" },
      { id: "ea2", name: "شاحن جداري أصلي طراز", unit: "قطعة", minQty: 20, wholesalePrice: 19500, image: "/images/cat-phone.jpg" },
      { id: "ea3", name: "كابل HDMI 2م", unit: "دستة", minQty: 5, wholesalePrice: 36000, image: "/images/cat-electro.jpg" },
    ],
  },
  {
    id: "nour-beauty",
    name: "مستحضرات نور",
    category: "beauty",
    city: "حلب — الجديدة",
    desc: "تجميل وعناية بالجملة للمحلات.",
    phone: "0944000006",
    shamCash: "",
    plan: "weekly",
    tags: ["كريمات", "عطور", "مكياج"],
    cover: "/images/cat-beauty.jpg",
    products: [
      { id: "nb1", name: "كريم مرطب علبة 12", unit: "كرتون", minQty: 4, wholesalePrice: 64000, image: "/images/cat-beauty.jpg" },
      { id: "nb2", name: "عطر حجم 100مل", unit: "قطعة", minQty: 12, wholesalePrice: 28000, image: "/images/cat-beauty.jpg" },
      { id: "nb3", name: "باليت مكياج جملة", unit: "قطعة", minQty: 10, wholesalePrice: 22500, image: "/images/cat-beauty.jpg" },
    ],
  },
  {
    id: "aleppo-build",
    name: "مستودعات حلب للبناء",
    category: "build",
    city: "حلب — الشيخ نجار",
    desc: "إسمنت وحديد وإكساء للمقاولين والمحلات.",
    phone: "0944000007",
    shamCash: "",
    plan: "weekly",
    tags: ["إسمنت", "حديد", "بلاط"],
    cover: "/images/cat-build.jpg",
    products: [
      { id: "ab1", name: "إسمنت كيس 50 كغ", unit: "كيس", minQty: 50, wholesalePrice: 42000, image: "/images/cat-build.jpg" },
      { id: "ab2", name: "حديد تسليح طن", unit: "طن", minQty: 1, wholesalePrice: 4200000, image: "/images/cat-build.jpg" },
      { id: "ab3", name: "بلاط أرضيات كرتون", unit: "متر", minQty: 40, wholesalePrice: 18500, image: "/images/cat-build.jpg" },
    ],
  },
  {
    id: "nour-office",
    name: "قرطاسية النور",
    category: "office",
    city: "حلب — العزيزية",
    desc: "قرطاسية ومدارس جملة للمكتبات.",
    phone: "0944000008",
    shamCash: "",
    plan: "trial",
    tags: ["دفاتر", "أقلام", "حقائب"],
    cover: "/images/cat-office.jpg",
    products: [
      { id: "no1", name: "دفتر 80 ورقة كرتون", unit: "كرتون", minQty: 5, wholesalePrice: 48000, image: "/images/cat-office.jpg" },
      { id: "no2", name: "أقلام جاف دستة", unit: "دستة", minQty: 20, wholesalePrice: 8500, image: "/images/cat-office.jpg" },
      { id: "no3", name: "حقيبة مدرسية", unit: "قطعة", minQty: 10, wholesalePrice: 35000, image: "/images/cat-office.jpg" },
    ],
  },
];

export const CATEGORY_SELECT: { id: CategoryId | "other"; name: string }[] = [
  ...CATEGORIES.map((c) => ({ id: c.id, name: c.name })),
  { id: "other", name: "أخرى" },
];

