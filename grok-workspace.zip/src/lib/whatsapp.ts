export function toWaDigits(raw: string) {
  let digits = raw.replace(/\D/g, "");
  if (!digits) return "";
  if (digits.startsWith("00")) digits = digits.slice(2);
  if (digits.startsWith("963")) return digits;
  if (digits.startsWith("0")) return `963${digits.slice(1)}`;
  return `963${digits}`;
}

export function waLink(phone: string, text: string) {
  const digits = toWaDigits(phone);
  if (!digits) return "";
  return `https://wa.me/${digits}?text=${encodeURIComponent(text)}`;
}

export function displayPhone(raw: string) {
  const d = raw.replace(/\D/g, "");
  if (d.startsWith("00963") && d.length >= 13) {
    const rest = d.slice(5);
    return `00963 ${rest.slice(0, 3)} ${rest.slice(3, 6)} ${rest.slice(6)}`.trim();
  }
  if (d.startsWith("963") && d.length >= 11) {
    const rest = d.slice(3);
    return `+963 ${rest.slice(0, 3)} ${rest.slice(3, 6)} ${rest.slice(6)}`.trim();
  }
  if (d.length === 10 && d.startsWith("09")) {
    return `${d.slice(0, 4)} ${d.slice(4, 7)} ${d.slice(7)}`;
  }
  return raw;
}
