import { create } from "zustand";
import { persist } from "zustand/middleware";
import { DEFAULT_SETTINGS, SEED_MERCHANTS } from "./data";
import type { JoinRequest, Merchant, SiteSettings } from "./types";

type RemonState = {
  settings: SiteSettings;
  merchants: Merchant[];
  requests: JoinRequest[];
  adminAuthed: boolean;
  updateSettings: (patch: Partial<SiteSettings>) => void;
  addRequest: (req: Omit<JoinRequest, "id" | "createdAt">) => JoinRequest;
  removeRequest: (id: string) => void;
  upsertMerchant: (m: Merchant) => void;
  removeMerchant: (id: string) => void;
  loginAdmin: (user: string, pass: string) => boolean;
  logoutAdmin: () => void;
};

export const ADMIN_USER = "مؤسس";
export const ADMIN_PASS = "admin123";

export const useRemonStore = create<RemonState>()(
  persist(
    (set, get) => ({
      settings: DEFAULT_SETTINGS,
      merchants: SEED_MERCHANTS,
      requests: [],
      adminAuthed: false,
      updateSettings: (patch) =>
        set({ settings: { ...get().settings, ...patch } }),
      addRequest: (req) => {
        const row: JoinRequest = {
          ...req,
          id: `req-${Date.now()}`,
          createdAt: new Date().toISOString(),
        };
        set({ requests: [row, ...get().requests] });
        return row;
      },
      removeRequest: (id) =>
        set({ requests: get().requests.filter((r) => r.id !== id) }),
      upsertMerchant: (m) => {
        const list = get().merchants;
        const i = list.findIndex((x) => x.id === m.id);
        if (i >= 0) {
          const next = list.slice();
          next[i] = m;
          set({ merchants: next });
        } else {
          set({ merchants: [m, ...list] });
        }
      },
      removeMerchant: (id) =>
        set({ merchants: get().merchants.filter((m) => m.id !== id) }),
      loginAdmin: (user, pass) => {
        const ok = user.trim() === ADMIN_USER && pass === ADMIN_PASS;
        if (ok) set({ adminAuthed: true });
        return ok;
      },
      logoutAdmin: () => set({ adminAuthed: false }),
    }),
    {
      name: "remon-market-v1",
      partialize: (s) => ({
        settings: s.settings,
        merchants: s.merchants,
        requests: s.requests,
      }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<RemonState>;
        return {
          ...current,
          ...p,
          settings: {
            ...DEFAULT_SETTINGS,
            ...p.settings,
            shamCashAccount:
              p.settings?.shamCashAccount || DEFAULT_SETTINGS.shamCashAccount,
            contactPhone:
              p.settings?.contactPhone || DEFAULT_SETTINGS.contactPhone,
          },
          merchants: p.merchants?.length ? p.merchants : current.merchants,
        };
      },
    },
  ),
);

export function useMerchant(id: string) {
  return useRemonStore((s) => s.merchants.find((m) => m.id === id));
}
