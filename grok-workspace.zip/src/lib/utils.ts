import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatSyp(n: number) {
  return `${n.toLocaleString("ar-SY")} ل.س`;
}
