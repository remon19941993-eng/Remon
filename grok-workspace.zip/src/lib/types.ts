export type CategoryId =
  | "fabric"
  | "food"
  | "home"
  | "phone"
  | "build"
  | "beauty"
  | "office";

export type PlanId = "trial" | "weekly";

export type Product = {
  id: string;
  name: string;
  unit: string;
  minQty: number;
  wholesalePrice: number;
  image: string;
};

export type Merchant = {
  id: string;
  name: string;
  category: CategoryId;
  city: string;
  desc: string;
  phone: string;
  shamCash: string;
  plan: PlanId;
  tags: string[];
  cover: string;
  products: Product[];
};

export type JoinRequest = {
  id: string;
  name: string;
  category: CategoryId | "other";
  phone: string;
  shamCash: string;
  city: string;
  desc: string;
  plan: PlanId;
  createdAt: string;
};

export type SiteSettings = {
  shamCashAccount: string;
  shamCashName: string;
  contactPhone: string;
  weeklyPrice: number;
  trialDays: number;
};
