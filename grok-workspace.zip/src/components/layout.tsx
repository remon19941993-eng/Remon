import { Link, useRouterState } from "@tanstack/react-router";
import { CreditCard, Home, Store, UserPlus } from "lucide-react";
import { cn } from "@/lib/utils";
import { displayPhone } from "@/lib/whatsapp";
import { useRemonStore } from "@/lib/store";

const NAV = [
  { to: "/", label: "الرئيسية", icon: Home },
  { to: "/merchants", label: "التجار", icon: Store },
  { to: "/plans", label: "اشتراك", icon: CreditCard },
  { to: "/join", label: "انضم", icon: UserPlus },
] as const;

export function Shell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const settings = useRemonStore((s) => s.settings);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="bg-ink px-4 py-2 text-center text-xs text-cream">
        منصة احترافية لتجار سوريا — الاشتراك عبر شام كاش
        {settings.contactPhone ? (
          <span className="mx-2 hidden sm:inline" dir="ltr">
            · {displayPhone(settings.contactPhone)}
          </span>
        ) : null}
      </div>
      <header className="sticky top-0 z-40 border-b border-border bg-surface/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
          <Link to="/" className="flex items-center gap-2">
            <span className="flex size-10 items-center justify-center rounded-xl bg-linear-to-br from-gold to-gold-deep text-lg font-bold text-white shadow-card">
              R
            </span>
            <span className="leading-tight">
              <span className="block font-bold text-fg">
                ريمون <span className="text-sm font-medium text-gold-deep">Remon</span>
              </span>
              <span className="block text-[10px] text-faint">سوق التجار</span>
            </span>
          </Link>
          <nav className="hidden items-center gap-1 sm:flex">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "rounded-lg px-3 py-2 text-sm transition-colors",
                  pathname === item.to
                    ? "bg-cream font-medium text-fg"
                    : "text-muted hover:bg-cream hover:text-fg",
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <Link
            to="/join"
            className="hidden h-10 items-center rounded-xl bg-primary px-4 text-sm font-medium text-bg sm:inline-flex"
          >
            سجّل متجرك
          </Link>
        </div>
      </header>
      <main className="pb-24 sm:pb-0">{children}</main>
      <footer className="mt-16 bg-ink text-cream">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:grid-cols-3">
          <div>
            <div className="font-bold text-white">ريمون — سوق التجار</div>
            <p className="mt-2 text-sm leading-relaxed text-faint">
              منصة محلية على نموذج علي بابا: التاجر يشترك، يعرض بضاعته، والزبون يتواصل مباشرة.
            </p>
          </div>
          <div className="text-sm">
            <div className="font-bold text-white">حساب شام كاش</div>
            <p dir="ltr" className="mt-2 break-all font-mono text-gold">
              {settings.shamCashAccount}
            </p>
            <p className="mt-1 text-faint">{settings.shamCashName}</p>
          </div>
          <div className="text-sm">
            <div className="font-bold text-white">رقم التواصل</div>
            <p dir="ltr" className="mt-2 text-gold">
              {displayPhone(settings.contactPhone)}
            </p>
            <Link to="/admin" className="mt-3 inline-block text-xs text-faint hover:text-cream">
              لوحة الإدارة
            </Link>
          </div>
        </div>
        <div className="border-t border-white/10 py-4 text-center text-xs text-faint">
          © 2026 Remon — ريمون. سوق التجار السوري. وسيط عرض غير مسؤول عن الاتفاقات بين الأطراف.
        </div>
      </footer>
      <nav className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-4 border-t border-border bg-surface sm:hidden">
        {NAV.map((item) => {
          const Icon = item.icon;
          const on = pathname === item.to;
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex h-16 flex-col items-center justify-center gap-1 text-[11px]",
                on ? "font-bold text-fg" : "text-muted",
              )}
            >
              <Icon className="size-5" />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
