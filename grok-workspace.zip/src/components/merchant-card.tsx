import { Link } from "@tanstack/react-router";
import { MapPin, MessageCircle } from "lucide-react";
import { CATEGORY_MAP } from "@/lib/data";
import type { Merchant } from "@/lib/types";
import { waLink } from "@/lib/whatsapp";
import { cn } from "@/lib/utils";

export function MerchantCard({ merchant }: { merchant: Merchant }) {
  const cat = CATEGORY_MAP[merchant.category];
  const wa = waLink(
    merchant.phone,
    `مرحبا، شفت متج ${merchant.name} على ريمون وأريد الاستفسار عن البضاعة`,
  );

  return (
    <article className="group flex flex-col overflow-hidden rounded-[1.25rem] bg-surface shadow-card transition-[box-shadow,transform] duration-200 hover:shadow-card-hover">
      <Link
        to="/merchants/$id"
        params={{ id: merchant.id }}
        className="relative block aspect-[16/10] overflow-hidden"
      >
        <img
          src={merchant.cover}
          alt=""
          className="size-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
        />
        <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-ink/70 to-transparent" />
        <span
          className={cn(
            "absolute top-3 right-3 rounded-full px-2.5 py-1 text-[10px] font-bold",
            merchant.plan === "weekly"
              ? "bg-gold text-ink"
              : "bg-cream text-muted",
          )}
        >
          {merchant.plan === "weekly" ? "مشترك" : "تجربة"}
        </span>
        <span className="absolute bottom-3 right-3 text-xs font-medium text-white">
          {cat?.name}
        </span>
      </Link>
      <div className="flex flex-1 flex-col p-4">
        <Link to="/merchants/$id" params={{ id: merchant.id }}>
          <h3 className="font-bold leading-snug text-fg">{merchant.name}</h3>
        </Link>
        <p className="mt-1 flex items-center gap-1 text-xs text-muted">
          <MapPin className="size-3.5" />
          {merchant.city}
        </p>
        <p className="mt-2 line-clamp-2 flex-1 text-sm text-muted">{merchant.desc}</p>
        <p className="mt-2 text-xs text-faint">{merchant.tags.join(" · ")}</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <Link
            to="/merchants/$id"
            params={{ id: merchant.id }}
            className="flex h-11 items-center justify-center rounded-xl bg-cream text-sm font-medium text-fg transition-transform active:scale-[0.96]"
          >
            البضاعة
          </Link>
          <a
            href={wa}
            target="_blank"
            rel="noreferrer"
            className="flex h-11 items-center justify-center gap-1.5 rounded-xl bg-primary text-sm font-medium text-bg transition-transform active:scale-[0.96]"
          >
            <MessageCircle className="size-4" />
            واتساب
          </a>
        </div>
      </div>
    </article>
  );
}
