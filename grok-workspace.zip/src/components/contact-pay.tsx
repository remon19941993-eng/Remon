import { MessageCircle, Wallet } from "lucide-react";
import { useRemonStore } from "@/lib/store";
import { displayPhone, waLink } from "@/lib/whatsapp";
import { CopyRow } from "./copy-row";

export function ContactPay({
  compact = false,
  waMessage = "مرحبا، تواصل من منصة ريمون",
}: {
  compact?: boolean;
  waMessage?: string;
}) {
  const settings = useRemonStore((s) => s.settings);
  const wa = waLink(settings.contactPhone, waMessage);

  return (
    <section
      className={
        compact
          ? "rounded-2xl bg-surface p-4 shadow-card"
          : "rounded-[1.5rem] bg-surface p-5 shadow-card sm:p-6"
      }
    >
      <div className="mb-4 flex items-center gap-2">
        <span className="flex size-10 items-center justify-center rounded-xl bg-gold/20 text-gold-deep">
          <Wallet className="size-5" />
        </span>
        <div>
          <h3 className="font-bold text-fg">حساب شام كاش ورقم التواصل</h3>
          <p className="text-xs text-muted">{settings.shamCashName}</p>
        </div>
      </div>
      <div className="space-y-2">
        <CopyRow
          label="حساب شام كاش"
          value={settings.shamCashAccount}
          mono
        />
        <CopyRow
          label="رقم التواصل"
          value={displayPhone(settings.contactPhone) || settings.contactPhone}
          copyValue={settings.contactPhone}
        />
      </div>
      {wa ? (
        <a
          href={wa}
          target="_blank"
          rel="noreferrer"
          className="mt-4 flex h-12 items-center justify-center gap-2 rounded-xl bg-wa text-sm font-bold text-white transition-colors hover:bg-wa-hover active:scale-[0.96]"
        >
          <MessageCircle className="size-4" />
          واتساب — تواصل مع ريمون
        </a>
      ) : null}
    </section>
  );
}
