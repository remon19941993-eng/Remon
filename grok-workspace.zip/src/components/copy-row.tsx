import { useState } from "react";
import { Check, Copy } from "lucide-react";
import { cn } from "@/lib/utils";

export function CopyRow({
  label,
  value,
  copyValue,
  dir = "ltr",
  mono = false,
}: {
  label: string;
  value: string;
  copyValue?: string;
  dir?: "ltr" | "rtl";
  mono?: boolean;
}) {
  const [copied, setCopied] = useState(false);
  if (!value) return null;

  async function copy() {
    try {
      await navigator.clipboard.writeText(copyValue || value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      /* ignore */
    }
  }

  return (
    <div className="flex items-center gap-3 rounded-2xl bg-cream px-4 py-3">
      <div className="min-w-0 flex-1">
        <div className="text-xs text-faint">{label}</div>
        <div
          dir={dir}
          className={cn(
            "mt-0.5 break-all text-base font-semibold text-fg",
            mono && "font-mono text-sm tracking-wide",
          )}
        >
          {value}
        </div>
      </div>
      <button
        type="button"
        onClick={copy}
        className="inline-flex h-11 min-w-11 items-center justify-center gap-1 rounded-xl bg-surface px-3 text-sm font-medium text-fg shadow-card transition-transform duration-150 active:scale-[0.96]"
        aria-label={`نسخ ${label}`}
      >
        {copied ? <Check className="size-4 text-wa" /> : <Copy className="size-4" />}
        <span className="hidden sm:inline">{copied ? "تم" : "نسخ"}</span>
      </button>
    </div>
  );
}
