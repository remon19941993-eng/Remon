import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, MapPin, MessageCircle, Wallet } from "lucide-react";
import { CopyRow } from "@/components/copy-row";
import { Shell } from "@/components/layout";
import { CATEGORY_MAP } from "@/lib/data";
import { useMerchant } from "@/lib/store";
import { formatSyp } from "@/lib/utils";
import { displayPhone, waLink } from "@/lib/whatsapp";

export const Route = createFileRoute("/merchants/$id")({
  component: MerchantPage,
});

function MerchantPage() {
  const { id } = Route.useParams();
  const merchant = useMerchant(id);

  if (!merchant) {
    return (
      <Shell>
        <div className="mx-auto max-w-lg px-4 py-20 text-center">
          <h1 className="text-xl font-bold">التاجر غير موجود</h1>
          <Link to="/merchants" className="mt-4 inline-block text-sm text-muted">
            العودة للدليل
          </Link>
        </div>
      </Shell>
    );
  }

  const cat = CATEGORY_MAP[merchant.category];
  const wa = waLink(
    merchant.phone,
    `مرحبا، شفت متجر ${merchant.name} على ريمون وأريد الاستفسار عن البضاعة`,
  );

  return (
    <Shell>
      <div className="relative h-52 overflow-hidden md:h-72">
        <img src={merchant.cover} alt="" className="size-full object-cover" />
        <div className="absolute inset-0 bg-linear-to-t from-ink via-ink/30 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 mx-auto max-w-6xl px-4 pb-5">
          <Link to="/merchants" className="mb-3 inline-flex items-center gap-1 text-sm text-cream">
            <ArrowRight className="size-4" />
            الدليل
          </Link>
          <h1 className="text-2xl font-bold text-white md:text-3xl">{merchant.name}</h1>
          <p className="mt-1 flex items-center gap-1 text-sm text-cream/80">
            <MapPin className="size-4" />
            {merchant.city} · {cat?.name}
          </p>
        </div>
      </div>

      <div className="mx-auto grid max-w-6xl gap-6 px-4 py-8 lg:grid-cols-[1fr_320px]">
        <div>
          <p className="leading-relaxed text-muted">{merchant.desc}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {merchant.tags.map((t) => (
              <span key={t} className="rounded-full bg-cream px-3 py-1 text-xs text-muted">
                {t}
              </span>
            ))}
          </div>
          <h2 className="mt-8 mb-4 text-lg font-bold">بضاعة الجملة</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {merchant.products.map((p) => {
              const pWa = waLink(
                merchant.phone,
                `مرحبا، أريد طلب جملة من ريمون:\nالمنتج: ${p.name}\nالحد الأدنى: ${p.minQty} ${p.unit}`,
              );
              return (
                <article key={p.id} className="overflow-hidden rounded-2xl bg-surface shadow-card">
                  <img src={p.image} alt="" className="h-36 w-full object-cover" />
                  <div className="p-4">
                    <h3 className="font-bold">{p.name}</h3>
                    <p className="mt-1 text-sm text-muted">
                      من {p.minQty} {p.unit}
                    </p>
                    <p className="mt-2 font-bold text-gold-deep tabular-nums">
                      {formatSyp(p.wholesalePrice)}
                      <span className="mr-1 text-xs font-medium text-faint">/ {p.unit}</span>
                    </p>
                    <a
                      href={pWa}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-3 flex h-11 items-center justify-center gap-1.5 rounded-xl bg-primary text-sm font-medium text-bg"
                    >
                      <MessageCircle className="size-4" />
                      اطلب عبر واتساب
                    </a>
                  </div>
                </article>
              );
            })}
          </div>
        </div>

        <aside className="space-y-3 lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-[1.25rem] bg-surface p-4 shadow-card">
            <h3 className="mb-3 font-bold">تواصل مع التاجر</h3>
            <CopyRow label="رقم التواصل" value={displayPhone(merchant.phone)} copyValue={merchant.phone} />
            {merchant.shamCash ? (
              <div className="mt-2">
                <CopyRow label="شام كاش التاجر" value={merchant.shamCash} mono />
              </div>
            ) : null}
            <a
              href={wa}
              target="_blank"
              rel="noreferrer"
              className="mt-3 flex h-12 items-center justify-center gap-2 rounded-xl bg-wa font-bold text-white hover:bg-wa-hover"
            >
              <MessageCircle className="size-4" />
              واتساب
            </a>
          </div>
          <p className="flex items-start gap-2 text-xs leading-relaxed text-faint">
            <Wallet className="mt-0.5 size-3.5 shrink-0" />
            الاتفاق والدفع مباشرة بينك وبين التاجر. ريمون وسيط عرض فقط.
          </p>
        </aside>
      </div>
    </Shell>
  );
}
