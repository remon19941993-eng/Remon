import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/layout";
import { ADMIN_PASS, ADMIN_USER, useRemonStore } from "@/lib/store";

export const Route = createFileRoute("/admin")({ component: AdminPage });

function AdminPage() {
  const authed = useRemonStore((s) => s.adminAuthed);
  const login = useRemonStore((s) => s.loginAdmin);
  const logout = useRemonStore((s) => s.logoutAdmin);
  const settings = useRemonStore((s) => s.settings);
  const updateSettings = useRemonStore((s) => s.updateSettings);
  const requests = useRemonStore((s) => s.requests);
  const removeRequest = useRemonStore((s) => s.removeRequest);
  const merchants = useRemonStore((s) => s.merchants);
  const upsertMerchant = useRemonStore((s) => s.upsertMerchant);
  const [err, setErr] = useState("");

  if (!authed) {
    return (
      <Shell>
        <form
          className="mx-auto mt-16 max-w-sm space-y-4 rounded-[1.25rem] bg-surface p-5 shadow-card"
          onSubmit={(e) => {
            e.preventDefault();
            const fd = new FormData(e.currentTarget);
            const ok = login(String(fd.get("user")), String(fd.get("pass")));
            setErr(ok ? "" : "بيانات الدخول غير صحيحة");
          }}
        >
          <h1 className="text-center text-xl font-bold">لوحة الإدارة</h1>
          <label className="block text-sm">
            اسم المستخدم
            <input name="user" className="field mt-1" autoComplete="username" />
          </label>
          <label className="block text-sm">
            كلمة المرور
            <input
              name="pass"
              type="password"
              className="field mt-1"
              autoComplete="current-password"
            />
          </label>
          {err ? <p className="text-sm text-red-700">{err}</p> : null}
          <button type="submit" className="h-11 w-full rounded-xl bg-primary font-bold text-bg">
            دخول
          </button>
          <p className="text-center text-xs text-faint">
            للمعاينة: {ADMIN_USER} / {ADMIN_PASS}
          </p>
        </form>
      </Shell>
    );
  }

  return (
    <Shell>
      <div className="mx-auto max-w-3xl space-y-8 px-4 py-10">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">لوحة ريمون</h1>
          <button type="button" onClick={logout} className="text-sm text-muted">
            خروج
          </button>
        </div>

        <section className="rounded-[1.25rem] bg-surface p-5 shadow-card">
          <h2 className="font-bold">حساب شام كاش ورقم التواصل</h2>
          <div className="mt-4 grid gap-3">
            <label className="text-sm">
              حساب شام كاش
              <input
                dir="ltr"
                className="field mt-1 font-mono"
                value={settings.shamCashAccount}
                onChange={(e) => updateSettings({ shamCashAccount: e.target.value })}
              />
            </label>
            <label className="text-sm">
              اسم الحساب
              <input
                className="field mt-1"
                value={settings.shamCashName}
                onChange={(e) => updateSettings({ shamCashName: e.target.value })}
              />
            </label>
            <label className="text-sm">
              رقم التواصل
              <input
                dir="ltr"
                className="field mt-1"
                value={settings.contactPhone}
                onChange={(e) => updateSettings({ contactPhone: e.target.value })}
              />
            </label>
            <label className="text-sm">
              الاشتراك الأسبوعي (ل.س)
              <input
                type="number"
                className="field mt-1"
                value={settings.weeklyPrice}
                onChange={(e) => updateSettings({ weeklyPrice: Number(e.target.value) || 0 })}
              />
            </label>
          </div>
        </section>

        <section className="rounded-[1.25rem] bg-surface p-5 shadow-card">
          <h2 className="font-bold">طلبات الانضمام ({requests.length})</h2>
          {requests.length === 0 ? (
            <p className="mt-3 text-sm text-muted">لا توجد طلبات جديدة.</p>
          ) : (
            <ul className="mt-4 space-y-3">
              {requests.map((r) => (
                <li key={r.id} className="rounded-xl bg-cream p-3 text-sm">
                  <div className="font-bold">{r.name}</div>
                  <div className="mt-1 text-muted">
                    {r.city} · {r.phone}
                    {r.shamCash ? ` · شام كاش ${r.shamCash}` : ""}
                  </div>
                  <p className="mt-1 text-muted">{r.desc}</p>
                  <button
                    type="button"
                    className="mt-2 text-xs text-faint"
                    onClick={() => removeRequest(r.id)}
                  >
                    حذف
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-[1.25rem] bg-surface p-5 shadow-card">
          <h2 className="font-bold">التجار ({merchants.length})</h2>
          <ul className="mt-4 space-y-2">
            {merchants.map((m) => (
              <li
                key={m.id}
                className="flex items-center justify-between gap-3 rounded-xl bg-cream px-3 py-2 text-sm"
              >
                <div>
                  <div className="font-medium">{m.name}</div>
                  <div className="text-xs text-muted" dir="ltr">
                    {m.plan === "weekly" ? "مشترك" : "تجربة"} · {m.phone}
                  </div>
                </div>
                <button
                  type="button"
                  className="text-xs"
                  onClick={() =>
                    upsertMerchant({
                      ...m,
                      plan: m.plan === "weekly" ? "trial" : "weekly",
                    })
                  }
                >
                  تبديل الباقة
                </button>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </Shell>
  );
}
