import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, BadgeCheck, Store, Tags, Wallet } from "lucide-react";
import { ContactPay } from "@/components/contact-pay";
import { Shell } from "@/components/layout";
import { MerchantCard } from "@/components/merchant-card";
import { CATEGORIES } from "@/lib/data";
import { useRemonStore } from "@/lib/store";
import { formatSyp } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const merchants = useRemonStore((s) => s.merchants);
  const settings = useRemonStore((s) => s.settings);
  const featured = merchants.filter((m) => m.plan === "weekly").slice(0, 3);

  return (
    <Shell>
      <section className="relative overflow-hidden bg-ink text-cream">
        <img
          src="/images/hero-souk.jpg"
          alt=""
          className="absolute inset-0 size-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-linear-to-l from-ink via-ink/80 to-ink/40" />
        <div className="relative mx-auto max-w-6xl px-4 py-16 md:py-24">
          <div className="max-w-xl">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-1 text-xs">
              <span className="size-2 rounded-full bg-gold" />
              منصة التجار — نموذج علي بابا المحلي
            </div>
            <h1 className="text-3xl font-bold leading-tight text-white md:text-5xl">
              اعرض بضاعتك للتجار
              <br />
              <span className="text-gold">واستقبل طلبات الجملة</span>
            </h1>
            <p className="mt-5 text-base leading-relaxed text-cream/80 md:text-lg">
              ريمون تربط التجار بالمشترين في حلب وسوريا. التاجر يشترك، يظهر، ويصل للزبون — بدون مخزون علينا وبدون تعقيد.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/join"
                className="inline-flex h-12 items-center rounded-xl bg-gold px-6 font-bold text-ink transition-transform active:scale-[0.96]"
              >
                انضم كتاجر الآن
              </Link>
              <Link
                to="/merchants"
                className="inline-flex h-12 items-center rounded-xl border border-white/20 bg-white/10 px-6 text-white transition-transform active:scale-[0.96]"
              >
                تصفح التجار
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="relative z-10 mx-auto -mt-8 max-w-6xl px-4">
        <div className="grid grid-cols-3 gap-3">
          <Stat value={String(merchants.length)} label="تاجر مسجّل" />
          <Stat value={String(CATEGORIES.length)} label="تصنيفات" />
          <Stat value={formatSyp(settings.weeklyPrice)} label="أسبوعيًا" gold />
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14">
        <h2 className="mb-6 text-xl font-bold md:text-2xl">تصنيفات الجملة</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {CATEGORIES.map((c) => {
            const Icon = c.icon;
            return (
              <Link
                key={c.id}
                to="/merchants"
                search={{ cat: c.id }}
                className="group overflow-hidden rounded-[1.25rem] bg-surface shadow-card transition-[box-shadow,transform] duration-200 hover:shadow-card-hover"
              >
                <div className="relative aspect-[5/3] overflow-hidden">
                  <img
                    src={c.image}
                    alt=""
                    className="size-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-ink/25" />
                  <span className="absolute top-2 right-2 flex size-8 items-center justify-center rounded-lg bg-surface/90">
                    <Icon className="size-4 text-fg" />
                  </span>
                </div>
                <div className="p-3">
                  <div className="text-sm font-bold">{c.name}</div>
                  <div className="mt-0.5 text-xs text-muted">{c.blurb}</div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      <section className="border-y border-border bg-surface py-14">
        <div className="mx-auto max-w-6xl px-4">
          <div className="mb-6 flex items-center justify-between">
            <h2 className="text-xl font-bold md:text-2xl">تجار مميزون</h2>
            <Link to="/merchants" className="flex items-center gap-1 text-sm text-muted">
              عرض الكل
              <ArrowLeft className="size-4" />
            </Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((m) => (
              <MerchantCard key={m.id} merchant={m} />
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14">
        <h2 className="mb-8 text-center text-xl font-bold md:text-2xl">كيف يعمل ريمون؟</h2>
        <div className="grid gap-4 md:grid-cols-3">
          <Step n="1" title="التاجر يشترك" body="يسجّل متجره ويدفع الاشتراك عبر شام كاش ليظهر في المنصة." />
          <Step n="2" title="يعرض بضاعته" body="صور، أسعار جملة، ونوع النشاط — بشكل مرتب واحترافي." />
          <Step n="3" title="الزبون يجده" gold title2="الزبون يجده" body="المشترون والتجار يتواصلون مباشرة عبر واتساب ويتم الاتفاق." />
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-6 px-4 pb-8 lg:grid-cols-2">
        <div className="rounded-[1.5rem] bg-ink p-6 text-cream sm:p-8">
          <div className="flex items-center gap-2 text-gold">
            <Wallet className="size-5" />
            <span className="text-sm font-bold">الدفع والتواصل</span>
          </div>
          <h2 className="mt-3 text-2xl font-bold text-white">شام كاش + واتساب</h2>
          <p className="mt-2 text-sm leading-relaxed text-cream/70">
            التجربة {settings.trialDays} أيام مجانًا، بعدها {formatSyp(settings.weeklyPrice)} أسبوعيًا تُحوَّل إلى حساب شام كاش أدناه. للتفعيل أرسل صورة الإشعار على رقم التواصل.
          </p>
          <ul className="mt-5 space-y-2 text-sm">
            <li className="flex gap-2">
              <BadgeCheck className="size-4 text-gold" /> ظهور المتجر في الدليل
            </li>
            <li className="flex gap-2">
              <Store className="size-4 text-gold" /> زر واتساب مباشر للزبون
            </li>
            <li className="flex gap-2">
              <Tags className="size-4 text-gold" /> شارة مشترك نشط
            </li>
          </ul>
          <Link
            to="/plans"
            className="mt-6 inline-flex h-11 items-center rounded-xl bg-gold px-5 font-bold text-ink"
          >
            تفاصيل الاشتراك
          </Link>
        </div>
        <ContactPay waMessage="مرحبا، أريد الاستفسار عن الاشتراك في ريمون" />
      </section>
    </Shell>
  );
}

function Stat({
  value,
  label,
  gold,
}: {
  value: string;
  label: string;
  gold?: boolean;
}) {
  return (
    <div className="rounded-2xl bg-surface p-4 text-center shadow-card md:p-6">
      <div className={`text-xl font-bold tabular-nums md:text-3xl ${gold ? "text-gold-deep" : "text-fg"}`}>
        {value}
      </div>
      <div className="mt-1 text-xs text-muted md:text-sm">{label}</div>
    </div>
  );
}

function Step({
  n,
  title,
  title2,
  body,
  gold,
}: {
  n: string;
  title: string;
  title2?: string;
  body: string;
  gold?: boolean;
}) {
  return (
    <div className="rounded-[1.25rem] bg-surface p-6 text-center shadow-card">
      <div
        className={`mx-auto mb-4 flex size-12 items-center justify-center rounded-full text-lg font-bold ${gold ? "bg-gold/20 text-gold-deep" : "bg-cream text-fg"}`}
      >
        {n}
      </div>
      <h3 className="font-bold">{title2 ?? title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-muted">{body}</p>
    </div>
  );
}
