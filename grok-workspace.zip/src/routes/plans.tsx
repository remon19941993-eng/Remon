import { createFileRoute, Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { ContactPay } from "@/components/contact-pay";
import { Shell } from "@/components/layout";
import { useRemonStore } from "@/lib/store";
import { formatSyp } from "@/lib/utils";
import { waLink } from "@/lib/whatsapp";

export const Route = createFileRoute("/plans")({ component: PlansPage });

function PlansPage() {
  const settings = useRemonStore((s) => s.settings);
  const payWa = waLink(
    settings.contactPhone,
    `مرحبا، تم تحويل اشتراك ريمون إلى شام كاش\nالحساب: ${settings.shamCashAccount}\nاسم المتجر: `,
  );

  return (
    <Shell>
      <div className="mx-auto max-w-6xl px-4 py-10">
        <h1 className="text-center text-2xl font-bold">الاشتراك في ريمون</h1>
        <p className="mx-auto mt-2 max-w-md text-center text-sm text-muted">
          {settings.trialDays} أيام تجربة مجانية، بعدها {formatSyp(settings.weeklyPrice)} أسبوعيًا عبر شام كاش
        </p>

        <div className="mx-auto mt-10 grid max-w-2xl gap-4 md:grid-cols-2">
          <div className="rounded-[1.25rem] bg-surface p-6 shadow-card">
            <div className="text-center text-xs font-bold text-faint">للبدء</div>
            <h3 className="mt-1 text-center text-lg font-bold">تجربة مجانية</h3>
            <div className="my-4 text-center">
              <span className="text-3xl font-bold">مجانًا</span>
              <div className="mt-1 text-sm text-muted">{settings.trialDays} أيام</div>
            </div>
            <ul className="mb-6 space-y-2 text-sm text-muted">
              <Li>ظهور متجرك في الدليل</Li>
              <Li>زر تواصل واتساب</Li>
              <Li>بدون دفع مقدمًا</Li>
            </ul>
            <Link
              to="/join"
              search={{ plan: "trial" }}
              className="flex h-11 items-center justify-center rounded-xl bg-cream font-medium"
            >
              ابدأ التجربة
            </Link>
          </div>

          <div className="rounded-[1.25rem] bg-surface p-6 shadow-card ring-2 ring-gold">
            <div className="text-center text-xs font-bold text-gold-deep">بعد التجربة</div>
            <h3 className="mt-1 text-center text-lg font-bold">اشتراك أسبوعي</h3>
            <div className="my-4 text-center">
              <span className="text-3xl font-bold tabular-nums">
                {settings.weeklyPrice.toLocaleString("ar-SY")}
              </span>
              <span className="text-sm text-muted"> ل.س / أسبوعيًا</span>
            </div>
            <ul className="mb-6 space-y-2 text-sm text-muted">
              <Li>بقاء الظهور في المنصة</Li>
              <Li>شارة مشترك نشط</Li>
              <Li>الدفع عبر شام كاش</Li>
              <Li>تجديد كل أسبوع</Li>
            </ul>
            <Link
              to="/join"
              search={{ plan: "weekly" }}
              className="flex h-11 items-center justify-center rounded-xl bg-linear-to-l from-gold to-gold-deep font-bold text-ink"
            >
              اشترك الآن
            </Link>
          </div>
        </div>

        <div className="mx-auto mt-10 max-w-lg space-y-4">
          <ContactPay waMessage={`مرحبا، تم تحويل اشتراك ريمون. اسم المتجر: `} />
          <p className="text-center text-xs leading-relaxed text-muted">
            التجربة: {settings.trialDays} أيام مجانًا. بعدها حوّل {formatSyp(settings.weeklyPrice)} أسبوعيًا إلى حساب شام كاش، ثم أرسل صورة الإشعار مع اسم متجرك عبر واتساب لتجديد الاشتراك.
          </p>
          {payWa ? (
            <a
              href={payWa}
              target="_blank"
              rel="noreferrer"
              className="flex h-12 items-center justify-center rounded-xl bg-wa font-bold text-white hover:bg-wa-hover"
            >
              تأكيد الدفع عبر واتساب
            </a>
          ) : null}
        </div>
      </div>
    </Shell>
  );
}

function Li({ children }: { children: React.ReactNode }) {
  return (
    <li className="flex gap-2">
      <Check className="size-4 shrink-0 text-gold-deep" />
      {children}
    </li>
  );
}
