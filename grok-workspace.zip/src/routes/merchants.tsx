import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { Shell } from "@/components/layout";
import { MerchantCard } from "@/components/merchant-card";
import { CATEGORIES } from "@/lib/data";
import { useRemonStore } from "@/lib/store";
import type { CategoryId } from "@/lib/types";
import { cn } from "@/lib/utils";

type Search = { cat?: string; q?: string };

export const Route = createFileRoute("/merchants")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    cat: typeof s.cat === "string" ? s.cat : undefined,
    q: typeof s.q === "string" ? s.q : undefined,
  }),
  component: MerchantsPage,
});

function MerchantsPage() {
  const { cat, q } = Route.useSearch();
  const navigate = Route.useNavigate();
  const merchants = useRemonStore((s) => s.merchants);
  const [query, setQuery] = useState(q ?? "");

  const active = (cat as CategoryId | undefined) ?? "all";

  const list = useMemo(() => {
    const needle = query.trim();
    return merchants
      .filter((m) => (active === "all" ? true : m.category === active))
      .filter((m) => {
        if (!needle) return true;
        const hay = `${m.name} ${m.city} ${m.desc} ${m.tags.join(" ")}`;
        return hay.includes(needle);
      })
      .slice()
      .sort((a, b) => Number(b.plan === "weekly") - Number(a.plan === "weekly"));
  }, [merchants, active, query]);

  function setCat(id: string) {
    navigate({
      search: { cat: id === "all" ? undefined : id, q: query || undefined },
    });
  }

  return (
    <Shell>
      <div className="mx-auto max-w-6xl px-4 py-10">
        <h1 className="text-2xl font-bold">دليل التجار</h1>
        <p className="mt-1 text-sm text-muted">ابحث حسب التصنيف أو الاسم</p>

        <label className="relative mt-6 block">
          <Search className="pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-faint" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="اسم التاجر أو البضاعة..."
            className="h-12 w-full rounded-2xl bg-surface pr-10 pl-4 shadow-card outline-none focus:ring-2 focus:ring-gold/50"
          />
        </label>

        <div className="mt-4 flex flex-wrap gap-2">
          <FilterChip on={active === "all"} onClick={() => setCat("all")}>
            الكل
          </FilterChip>
          {CATEGORIES.map((c) => (
            <FilterChip key={c.id} on={active === c.id} onClick={() => setCat(c.id)}>
              {c.name}
            </FilterChip>
          ))}
        </div>

        {list.length === 0 ? (
          <p className="py-16 text-center text-muted">لا يوجد تجار في هذا التصنيف بعد.</p>
        ) : (
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((m) => (
              <MerchantCard key={m.id} merchant={m} />
            ))}
          </div>
        )}
      </div>
    </Shell>
  );
}

function FilterChip({
  on,
  onClick,
  children,
}: {
  on: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-10 rounded-full px-3.5 text-sm transition-colors",
        on ? "bg-primary text-bg" : "bg-surface text-muted shadow-card",
      )}
    >
      {children}
    </button>
  );
}
