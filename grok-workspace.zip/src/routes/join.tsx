import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ContactPay } from "@/components/contact-pay";
import { Shell } from "@/components/layout";
import { CATEGORY_SELECT } from "@/lib/data";
import { useRemonStore } from "@/lib/store";
import type { CategoryId, PlanId } from "@/lib/types";
import { waLink } from "@/lib/whatsapp";

type Search = { plan?: string };

export const Route = createFileRoute("/join")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    plan: typeof s.plan === "string" ? s.plan : undefined,
  }),
  component: JoinPage,
});

function JoinPage() {
  const { plan: planQ } = Route.useSearch();
  const addRequest = useRemonStore((s) => s.addRequest);
  const settings = useRemonStore((s) => s.settings);
  const [sent, setSent] = useState(false);

  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const name = String(fd.get("name") || "").trim();
    const category = String(fd.get("category") || "other") as CategoryId | "other";
    const phone = String(fd.get("phone") || "").trim();
    const shamCash = String(fd.get("shamCash") || "").trim();
    const city = String(fd.get("city") || "").trim();
    const desc = String(fd.get("desc") || "").trim();
    const plan = (String(fd.get("plan") || "trial") as PlanId) || "trial";
    if (!name || !phone || !city) return;

    addRequest({ name, category, phone, shamCash, city, desc, plan });

    const text =
      `طلب انضمام لتاجر جديد على ريمون:\n` +
      `المتجر: ${name}\n` +
      `التصنيف: ${category}\n` +
      `الهاتف: ${phone}\n` +
      `شام كاش: ${shamCash || "-"}\n` +
      `المدينة: ${city}\n` +
      `الباقة: ${plan}\n` +
      `الوصف: ${desc || "-"}`;
    const href = waLink(settings.contactPhone, text);
    if (href) window.open(href, "_blank");
    setSent(true);
  }

  return (
    <Shell>
      <div className="mx-auto max-w-xl px-4 py-10">
        <h1 className="text-2xl font-bold">سجّل متجرك في ريمون</h1>
        <p className="mt-1 text-sm text-muted">املأ البيانات وسنتواصل معك لتفعيل الحساب</p>

        {sent ? (
          <div className="mt-8 rounded-[1.25rem] bg-surface p-6 text-center shadow-card">
            <h2 className="text-lg font-bold">وصل طلبك</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              افتح واتساب لإكمال الإرسال إن لم يُفتح تلقائيًا. يمكنك أيضًا تحويل الاشتراك إلى حساب شام كاش أدناه.
            </p>
            <div className="mt-5">
              <ContactPay waMessage="مرحبا، أرسلت طلب انضمام إلى ريمون" />
            </div>
          </div>
        ) : (
          <form
            onSubmit={onSubmit}
            className="mt-6 space-y-4 rounded-[1.25rem] bg-surface p-6 shadow-card"
          >
            <Field label="اسم المتجر / التاجر">
              <input
                name="name"
                required
                placeholder="مثال: مؤسسة النور للأقمشة"
                className="field"
              />
            </Field>
            <Field label="التصنيف">
              <select name="category" required className="field" defaultValue="">
                <option value="" disabled>
                  اختر التصنيف
                </option>
                {CATEGORY_SELECT.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="رقم التواصل (واتساب)">
              <input
                name="phone"
                required
                dir="ltr"
                placeholder="09xxxxxxxx"
                className="field"
              />
            </Field>
            <Field label="حساب شام كاش (اختياري)">
              <input
                name="shamCash"
                dir="ltr"
                placeholder="رقم أو معرف شام كاش"
                className="field"
              />
            </Field>
            <Field label="المدينة / الحي">
              <input name="city" required placeholder="حلب — الجميلية" className="field" />
            </Field>
            <Field label="وصف مختصر للبضاعة">
              <textarea
                name="desc"
                rows={3}
                placeholder="جملة أقمشة تركي، نصف جملة متاح..."
                className="field min-h-24"
              />
            </Field>
            <Field label="الباقة المطلوبة">
              <select
                name="plan"
                className="field"
                defaultValue={planQ === "weekly" ? "weekly" : "trial"}
              >
                <option value="trial">تجربة {settings.trialDays} أيام مجانًا</option>
                <option value="weekly">
                  اشتراك أسبوعي — {settings.weeklyPrice.toLocaleString("ar-SY")} ل.س
                </option>
              </select>
            </Field>
            <button
              type="submit"
              className="h-12 w-full rounded-xl bg-primary font-bold text-bg transition-transform active:scale-[0.96]"
            >
              إرسال طلب الانضمام
            </button>
          </form>
        )}

        {!sent ? (
          <div className="mt-8">
            <ContactPay compact waMessage="مرحبا، أريد الانضمام إلى ريمون كتاجر" />
          </div>
        ) : null}
      </div>
    </Shell>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-medium">{label}</span>
      {children}
    </label>
  );
}
